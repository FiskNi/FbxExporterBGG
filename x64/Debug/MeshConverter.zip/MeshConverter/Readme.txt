Input filepath to your fbx file with -i [filepath] 	(Without brackets)
Set your desired output filename with -m [name]		(Without brackets)

Example:
	Convert.exe -i C:/Users/Coolfile.fbx -n C00lFile